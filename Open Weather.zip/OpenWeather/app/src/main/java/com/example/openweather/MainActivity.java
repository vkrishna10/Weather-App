package com.example.openweather;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    //TODO: Get image for the ImageView Object
    EditText zipcode;
    Button search;
    TextView city, slogan, temp;
    TextView[][] forecast = new TextView[5][4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        zipcode = findViewById(R.id.editTextTextPersonName);
        search = findViewById(R.id.button);
        city = findViewById(R.id.textLocation);
        temp = findViewById(R.id.temp);
        slogan = findViewById(R.id.textView);

        forecast[0][0] = findViewById(R.id.textDay1);
        forecast[0][1] = findViewById(R.id.textWeather1);
        forecast[0][2] = findViewById(R.id.textView8);
        forecast[0][3] = findViewById(R.id.textView9);

        forecast[1][0] = findViewById(R.id.textDay2);
        forecast[1][1] = findViewById(R.id.textWeather2);
        forecast[1][2] = findViewById(R.id.textView10);
        forecast[1][3] = findViewById(R.id.textView11);

        forecast[2][0] = findViewById(R.id.textDay3);
        forecast[2][1] = findViewById(R.id.textWeather3);
        forecast[2][2] = findViewById(R.id.textView12);
        forecast[2][3] = findViewById(R.id.textView13);

        forecast[3][0] = findViewById(R.id.textDay4);
        forecast[3][1] = findViewById(R.id.textWeather4);
        forecast[3][2] = findViewById(R.id.textView14);
        forecast[3][3] = findViewById(R.id.textView15);

        forecast[4][0] = findViewById(R.id.textDay5);
        forecast[4][1] = findViewById(R.id.textWeather5);
        forecast[4][2] = findViewById(R.id.textView16);
        forecast[4][3] = findViewById(R.id.textView17);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    ImageView view1 = findViewById(R.id.WeatherImage);

                    //Geocoding API call
                    double[] coords = new double[2];
                    final String urlStringCoords = "https://api.openweathermap.org/geo/1.0/zip?zip=" +
                            zipcode.getText().toString() + "&appid=" +
                            "c1302fc7f67c863bd33f28a8f71f18d3";
                    GetCoordinates latLon = new GetCoordinates();
                    JSONObject coordinateData = latLon.execute(urlStringCoords).get();
                    if(coordinateData == null){
                        city.setText("Invalid Zipcode entered.");
                    } else {
                        coords[0] = Double.parseDouble(coordinateData.getString("lat"));
                        coords[1] = Double.parseDouble(coordinateData.getString("lon"));
                    }

                    GetCityName cities = new GetCityName();
                    String cit = cities.execute(coords).get();
                    city.setText(cit + " Lat: " + coords[0] + " Lon: " + coords[1]);


                    //Current weather API call
                    GetCurrentWeather currentWeather = new GetCurrentWeather();
                    JSONObject currentWeatherData = currentWeather.execute(coords).get();
                    String description = (String) currentWeatherData.getJSONArray("weather")
                            .getJSONObject(0).getString("main");
                    if(Pattern.compile(Pattern.quote("cloud"),Pattern.CASE_INSENSITIVE).matcher(description).find()) {
                        view1.setImageResource(R.drawable.img);
                        slogan.setText("Too cloudy for Gru");
                    } else if(Pattern.compile(Pattern.quote("sun"),Pattern.CASE_INSENSITIVE).matcher(description).find() || Pattern.compile(Pattern.quote("clear"),Pattern.CASE_INSENSITIVE).matcher(description).find()) {
                        view1.setImageResource(R.drawable.img_1);
                        slogan.setText("Its sunglasses time");
                    } else if(Pattern.compile(Pattern.quote("rain"),Pattern.CASE_INSENSITIVE).matcher(description).find()) {
                        view1.setImageResource(R.drawable.img_2);
                        slogan.setText("Gru is sad");
                    } else if(Pattern.compile(Pattern.quote("snow"),Pattern.CASE_INSENSITIVE).matcher(description).find()) {
                        view1.setImageResource(R.drawable.img_3);
                        slogan.setText("Time to make a snowman");
                    } else {
                        slogan.setText(description);
                    }

                    double tem = currentWeatherData.getJSONObject("main")
                            .getDouble("temp");
                    temp.setText(String.valueOf(tem) + " \u00B0" + "F");

                    // Get forecast data
                    GetForecast fore = new GetForecast();
                    JSONObject nextDays = fore.execute(coords).get();
                    for(int i = 0; i < forecast.length; i++){
                        JSONObject temp = nextDays.getJSONArray("list").
                                getJSONObject(i);
                        forecast[i][0].setText(convertToStandard(UTCtoEST((String) String.
                                valueOf(temp.get("dt_txt")).substring(11, 16))));

                        forecast[i][1].setText( String.valueOf(temp.getJSONObject("main").getDouble("temp")) + " \u00B0" + "F" );

                        forecast[i][2].setText( String.valueOf(temp.getJSONObject("main").getDouble("temp_min")) + " \u00B0" + "F");

                        forecast[i][3].setText( String.valueOf(temp.getJSONObject("main").getDouble("temp_max")) + " \u00B0" + "F");
                    }


                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });
    }

        public String convertToStandard(String dateTime){
            int hrs = Integer.parseInt(dateTime.substring(0, 2));
            if(hrs <= 12){
                return (dateTime + " AM");
            }else{
                String newFormat = "";
                newFormat +=(hrs - 12) + ":00 PM";
                return newFormat;
                }

        }


        public String UTCtoEST(String d){
            int newHr = Integer.parseInt(d.substring(0,2));
            newHr-=5;
            if(newHr < 0){
                newHr+=24;
            }
            String hrs = String.valueOf(newHr);
            if (hrs.length() == 2)
                return (newHr + d.substring(2));
            else
                return ("0" + newHr + d.substring(2));
        }
    }