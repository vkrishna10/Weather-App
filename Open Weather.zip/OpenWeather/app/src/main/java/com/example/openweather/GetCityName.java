package com.example.openweather;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class GetCityName extends AsyncTask<double[], Void, String> {
    /**
     * @param doubles
     * @deprecated
     */
    @Override
    protected String doInBackground(double[]... doubles) {
        double[] coords = doubles[0];
        final String urlCurrent = "https://api.openweathermap.org/geo/1.0/reverse?lat=" +
                coords[0] + "&lon=" + coords[1] + "&limit=1&appid=c1302fc7f67c863bd33f28a8f71f18d3";
        JSONArray weatherData = new JSONArray();
        String cityName = null;

        try {
            URL url = new URL(urlCurrent);
            HttpURLConnection connect =  (HttpURLConnection) url.openConnection();
            connect.setRequestMethod("GET");

            if(connect.getResponseCode() == 200) {
                InputStream connStream = connect.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(connStream));
                String line = reader.readLine();
                weatherData = new JSONArray(line);
                reader.close();
            }
            cityName = weatherData.getString(0);
            String[] arr = cityName.split(",")[0].substring(1).split(":");
            String str = arr[1].substring(1,arr[1].length() -1);
            cityName = str;
            Log.d("STRING", String.valueOf(cityName));

        } catch (MalformedURLException e) {
            Log.d("EXCEPTION", "Error with URL. STEP = GetCityName");
        } catch (IOException e) {
            Log.d("EXCEPTION", "IOException caught. STEP = GetCityName");
            e.printStackTrace();
        } catch(NullPointerException e) {
            Log.d("EXCEPTION", "NullPointerException caught. STEP = GetCityName");
        } catch(JSONException e){
            Log.d("EXCEPTION", "JSONException caught. STEP = GetCityName");
            e.printStackTrace();
        } catch (Exception e){
            Log.d("EXCEPTION", "UNKNOWN ORIGIN. STEP = GetCityName");
        }
        return cityName;
    }
}
