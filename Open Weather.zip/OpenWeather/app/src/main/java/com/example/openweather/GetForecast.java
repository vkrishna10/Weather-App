package com.example.openweather;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class GetForecast extends AsyncTask<double[], Void, JSONObject> {
    /**
     * @param doubles
     * @deprecated
     */
    @Override
    protected JSONObject doInBackground(double[]... doubles) {
        double[] coords = doubles[0];
        final String urlCurrent = "https://api.openweathermap.org/data/2.5/forecast?lat=" +
                coords[0] + "&lon=" + coords[1] +
                "&appid=c1302fc7f67c863bd33f28a8f71f18d3&units=imperial&cnt=5";
        JSONObject nextDays = new JSONObject();
        try {
            URL url = new URL(urlCurrent);
            HttpURLConnection connect =  (HttpURLConnection) url.openConnection();
            connect.setRequestMethod("GET");

            if(connect.getResponseCode() == 200) {
                InputStream connStream = connect.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(connStream));
                String line = reader.readLine();
                nextDays = new JSONObject(line);
                reader.close();
            }


        } catch (MalformedURLException e) {
            Log.d("EXCEPTION", "Error with URL. STEP = GetForecast");
        } catch (IOException e) {
            Log.d("EXCEPTION", "IOException caught. STEP = GetForecast");
        } catch(NullPointerException e){
            Log.d("EXCEPTION", "NullPointerException caught. STEP = GetForecast");
        } catch (Exception e){
            Log.d("EXCEPTION", "UNKNOWN ORIGIN. STEP = GetForecast");
        }
        return nextDays;
    }
}
