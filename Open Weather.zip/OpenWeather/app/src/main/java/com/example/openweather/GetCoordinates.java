package com.example.openweather;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

public class GetCoordinates extends AsyncTask<String, Void, JSONObject> {

    /**
     * @param params
     * @deprecated
     */
    @Override
    protected JSONObject doInBackground(String... params) {
        String urlString = params[0];
        JSONObject coordinateData = new JSONObject();

        try {
            URL url = new URL(urlString);
            HttpURLConnection connect =  (HttpURLConnection) url.openConnection();
            connect.setRequestMethod("GET");

            if(connect.getResponseCode() == 200) {
                InputStream connStream = connect.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(connStream));
                String line = reader.readLine();
                line = line.substring(1,line.length() - 1);
                String[] varPairs = line.split(",");
                for(int i = 0; i < varPairs.length; i++) {
                    String[] tempLine = varPairs[i].split(":");
                    String varName = tempLine[0].substring(1, tempLine[0].length() - 1);
                    String value = tempLine[1];
                    coordinateData.put(varName, value);
                }
                reader.close();
           }


        } catch (MalformedURLException e) {
            Log.d("EXCEPTION", "Error with URL. STEP = GetCoordinates");
            return null;
        } catch (IOException e) {
            Log.d("EXCEPTION", "IOException caught. STEP = GetCoordinates");
            return null;
        } catch(NullPointerException e){
            Log.d("EXCEPTION", "NullPointerException caught. STEP = GetCoordinates");
            return null;
        } catch (Exception e){
            Log.d("EXCEPTION", "UNKNOWN ORIGIN. STEP = GetCoordinates");
            return null;
        }

        return coordinateData;
    }


}
